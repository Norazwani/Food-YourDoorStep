<!DOCTYPE HTML> 
<html>
<head>
</head>
<body> 
<h4>
<text style="margin-auto: 200px">Place your order now and our delivery team will be in touch with you soon!</text> 
<hr>
</h4>

<form method="post" action="insertDB.php"> 
<table style="margin-left:40px" >
   <tr><td>Food:</td><td> <select name = "of">
 <option value="NL AG">Nasi Lemak Ayam Goreng(RM5)</option>
 <option value="NL AP">Nasi Lemak Ayam Pandan(RM6)</option>
 <option value="NL S">Nasi Lemak Special(RM10)</option>
 <option value="RP">Roti Pisang(RM3)</option>
 <option value="RK">Roti Kaya(RM2)</option>
 <option value="RC">Roti Canai(RM1)</option>
 <option value="SB">Spaghetti Bolognese(RM10)</option>
 <option value="SC">Spaghetti Carbonara(RM15)</option>
 <option value="SM">Spaghetti Meatball(RM20)</option>
<option value="NE">Nasi Ecuador(RM12)</option>
<option value="NGB">Nasi Goreng Belacan(RM7)</option>
<option value="MUD">Mee Udon(RM12)</option>
<option value="MUT">Mee Utara(RM14)</option>
<option value="MB">Mee Bandung(RM13)</option>
 </select><br><br></td></tr>

 <tr><td>Drinks:</td><td> <select name = "od">
 <option value="F&NAS">F&N Aiskrim Soda(RM2)</option>
 <option value="CC">Coca Cola(RM2)</option>
 <option value="FO">Fanta Orange(RM2)</option>
 <option value="BLB">Banana Love Boat(RM7.50)</option>
 <option value="CWC">Cendol With Corn(RM3.50)</option>
 <option value="CM&PC">Chilled Mango & Pomelo Cream(RM10.50)</option>
 </select><br><br></td></tr>

   <tr><td>Quantity of Food:</td><td><input type="number" maxlength="2" name="pa" min="1" max="10" required > 
   <br><br></td></tr>
   <tr><td>Quantity of Drinks:</td><td><input type="number" maxlength="2" name="pi" min="1" max="10" required > 
   <br><br></td></tr>
   <tr><td>Email:</td><td> <input type="email" name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required>
   <br><br></td></tr>
   <tr><td>Mobile Number(+60):</td><td> <input type="number" name="cm" maxlength="10" required>
   <br><br></td></tr>
   <tr><td>Current Address:</td><td><textarea rows="4" cols="25" name="ca" required></textarea>
   <br><br></td></tr>
   <tr><td></td><td><input type="submit" name="submit" value="Submit" > </td></tr>
   </table>
</form>

</body>
</html>