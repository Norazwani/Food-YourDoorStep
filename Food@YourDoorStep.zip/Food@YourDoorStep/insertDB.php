<?php
// define variables and set to empty values
$of = $od = $pa = $pi = $ca = $cm = $dbpn = $dbn = $price = $prices = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   $of = test_input($_POST["of"]);
   $od = test_input($_POST["od"]);
   $pa = test_input($_POST["pa"]);
   $pi = test_input($_POST["pi"]);
   $ca = test_input($_POST["ca"]);
   $cm = test_input($_POST["cm"]);
   if($of=="NL AG")
   { 
        $price = 5*$pa;
		}
	else if($of=="NL AP")
   { 
        $price = 6*$pa;
		}
	else if($of=="NL S")
   { 
        $price = 10*$pa;
        }
     else if($of=="RP")
   { 
        $price = 3*$pa;
        }
     else if($of=="RK")
    { 
        $price =2*$pa;
        }
     else if($of=="RC")
   { 
        $price = 1*$pa;
        }
    else if($of=="SB")
    { 
        $price = 10*$pa;
        }
    else if($of=="SC")
    { 
        $price = 15*$pa;
        }
    else if($of=="SM")
    { 
        $price = 20*$pa;
        }
    else if($of=="NE")
    { 
        $price = 12*$pa;
        }
    else if($of=="NG B")
    { 
        $price = 7*$pa;
        }
    else if($of=="MUD")
    { 
        $price = 12*$pa;
        }
    else if($of=="MUT")
    { 
        $price = 14*$pa;
        }
    else if($of=="MB")
    { 
        $price = 13*$pa;
        }
    else if($od=="F&NAS")
    { 
        $prices = 2*$pi;
        }
    else if($od=="CC")
    { 
        $prices = 2*$pi;
        }
    else if($od=="FO")
    { 
        $prices = 2*$pi;
        }
    else if($od=="BLB")
    { 
        $prices = 7.50*$pi;
        }
    else if($od=="CWC")
    { 
        $prices = 3.50*$pi;
        }
    else if($od=="CM&PC")
    { 
        $prices = 10.50*$pi;
        }

        echo "<br>You order is successful. <br>";
        echo "<br>Please wait for delivery team to send your order. <br>";
        echo "You have to pay RM:" .$price. " for your food.<br>";
        echo "You have to pay RM:" .$prices. " for your drinks.<br>";
}

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>


<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mydbb2";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO phptable2 (OrderDetails, PaymentAmount, CustomerAddress, CustomerMobile)
VALUES ('$od', '$pa', '$ca', '$cm')";

if ($conn->query($sql) === TRUE) {
    
	echo "Your order id is: ";
	$sql = "SELECT orderid FROM phptable2 WHERE  CustomerMobile='" . $cm . "'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
	
    {
	while($row = $result->fetch_assoc()) {
        echo $row["orderid"];
		
    }
    }
}
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
